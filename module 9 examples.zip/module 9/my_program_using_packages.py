import my_package

#This won't work
#print(my_package.module_2.knock_knock())

#Unless you import the modules in the package

from my_package import module_1, module_2

print(module_2.knock_knock())
print(module_1.whats_up_doc())