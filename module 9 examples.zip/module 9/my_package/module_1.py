def whats_up_doc():
    print("What's up doc?")
    return("")