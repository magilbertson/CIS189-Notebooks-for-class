def to_infinity():
    print("And beyond!")

def knock_knock():
    print("who's there?")
    return("")