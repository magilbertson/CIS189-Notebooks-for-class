def hello_class():
    print("hello!")

def hello_world():
    print("Hello everybody else!")

my_contact_info = {"name":"matt", "email":"magilbertson@dmacc.edu"}