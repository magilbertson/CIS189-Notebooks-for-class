import my_module

if __name__ == '__main__':
    my_module.hello_class()
    my_module.hello_world()

    print(my_module.my_contact_info)